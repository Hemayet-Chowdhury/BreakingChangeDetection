const fs = require("fs");
const ts = require("typescript");
const acorn = require('acorn');
const babel = require("@babel/core");
var readlineSync = require('readline-sync');
var NodeProcessor = require('./NodeProcessor');
var TreeAnalyser  = require('./TreeAnalyser');



var sourceString = "old_s4.txt"
var targetString = "new_S4.txt"

let filename1 = fs.readFileSync(sourceString, "utf8");
let filename2 = fs.readFileSync(targetString, "utf8");

const ts_source_ast = ts.createSourceFile('temp1.ts', filename1);
const ts_target_ast = ts.createSourceFile('temp2.ts', filename2);






let old_version_tree = new TreeAnalyser(ts_source_ast)
let new_version_tree = new TreeAnalyser(ts_target_ast)
// old_version_tree.printFunctionsList();
let myNodeProcessor = new NodeProcessor(old_version_tree, new_version_tree);
myNodeProcessor.printFunctionRemovals();
myNodeProcessor.printFunctionsAdded();

myNodeProcessor.printParameterChanges();



